import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

import { AppComponent } from './app.component';
import { AppEmployeepageLayoutModule } from './layout/app.employeepage.layout.module';
import { AppLayoutModule } from './layout/app.layout.module';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { CountryService } from './demo/service/country.service';
import { CustomerService } from './demo/service/customer.service';
import { DropdownModule } from 'primeng/dropdown';
import { EventService } from './demo/service/event.service';
import { IconService } from './demo/service/icon.service';
import { InputTextModule } from 'primeng/inputtext';
import { LoginModule } from "./demo/components/auth/login/login.module";
import { LoginServiceService } from 'src/app/demo/service/login-service.service'
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MultiSelectModule } from 'primeng/multiselect';
import { MydashboardComponent } from './demo/components/mydashboard/mydashboard.component';
import { NgModule } from '@angular/core';
import { NodeService } from './demo/service/node.service';
import { NotfoundComponent } from './demo/components/notfound/notfound.component';
import { PhotoService } from './demo/service/photo.service';
import { ProductService } from './demo/service/product.service';
import { ProgressBarModule } from 'primeng/progressbar';
import { RatingModule } from 'primeng/rating';
import { RippleModule } from 'primeng/ripple';
import { SliderModule } from 'primeng/slider';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { ToggleButtonModule } from 'primeng/togglebutton';

// import { LoginComponent } from './demo/components/auth/login/login.component';


















//New TODO mydasboard


















// import { NB_AUTH_OPTIONS, NbAuthService } from '@nebular/auth';
// import { InitUserService } from 'src/app/demo/service/init-user.service';
// import { ChangeDetectorRef } from '@angular/core';
// import { Router } from '@angular/router';
// import { NbThemeService } from '@nebular/theme';


@NgModule({
    declarations: [
        AppComponent, NotfoundComponent, MydashboardComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        AppRoutingModule,
        AppLayoutModule,
        // LoginModule,
        // AppEmployeepageLayoutModule,
        TableModule,
        CommonModule,
        RatingModule,
        ButtonModule,
        SliderModule,
        InputTextModule,
        ToggleButtonModule,
        RippleModule,
        MultiSelectModule,
        DropdownModule,
        ProgressBarModule,
        ToastModule,



    ],
    providers: [
        { provide: LocationStrategy, useClass: HashLocationStrategy, },
        CountryService, CustomerService, EventService, IconService, NodeService,LoginModule,
        PhotoService, ProductService, FormBuilder, LoginServiceService, AppEmployeepageLayoutModule,
        //NbThemeService, InitUserService, NbAuthService, Router,
    ],
    bootstrap: [AppComponent],


})
export class AppModule { }

import { AppConfigModule } from './config/config.module';
import { AppEmployeepageLayoutComponent } from "./app.employeepage.layout.component";
import { AppEmployeepageMenuComponent } from './app.employeepage.menu.component';
import { AppEmployeepageSidebarComponent } from "./app.employeepage.sidebar.component";
import { AppFooterComponent } from './app.footer.component';
import { AppLayoutComponent } from "./app.layout.component";
import { AppMenuitemComponent } from './app.menuitem.component';
import { AppTopBarComponent } from './app.topbar.component';
import { BadgeModule } from 'primeng/badge';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { FormlayoutModule } from 'src/app/demo/components/uikit/formlayout/formlayout.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputTextModule } from 'primeng/inputtext';
import { NgModule } from '@angular/core';
import { RadioButtonModule } from 'primeng/radiobutton';
import { RippleModule } from 'primeng/ripple';
import { RouterModule } from '@angular/router';
import { SidebarModule } from 'primeng/sidebar';

@NgModule({
    declarations: [
        // AppMenuitemComponent,
        // AppTopBarComponent,
        AppFooterComponent,
        AppEmployeepageMenuComponent,
        AppEmployeepageSidebarComponent,
        AppEmployeepageLayoutComponent,
        // FormlayoutModule
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        BrowserAnimationsModule,
        InputTextModule,
        SidebarModule,
        BadgeModule,
        RadioButtonModule,
        InputSwitchModule,
        RippleModule,
        RouterModule,
        AppConfigModule,
        // FormlayoutModule
    ],
    exports: [AppEmployeepageLayoutComponent]
})
export class AppEmployeepageLayoutModule { }

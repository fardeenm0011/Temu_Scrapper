import { Component, ElementRef } from '@angular/core';

import { LayoutService } from "./service/app.layout.service";

@Component({
    selector: 'app-employeepage-sidebar',
    templateUrl: './app.employeepage.sidebar.component.html'
})
export class AppEmployeepageSidebarComponent {
    constructor(public layoutService: LayoutService, public el: ElementRef) { }
}


import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { LayoutService } from 'src/app/layout/service/app.layout.service';
import { LoginServiceService } from 'src/app/demo/service/login-service.service';

// import {MatSnackBar} from '@angular/material/snack-bar';
// import {FormsModule,ReactiveFormsModule} from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styles: [`
        :host ::ng-deep .p-password input {
            width: 100%;
            padding:1rem;
        }

        :host ::ng-deep .pi-eye{
            transform:scale(1.6);
            margin-right: 1rem;
            color: var(--primary-color) !important;
        }

        :host ::ng-deep .pi-eye-slash{
            transform:scale(1.6);
            margin-right: 1rem;
            color: var(--primary-color) !important;
        }
    `]
})
export class LoginComponent implements OnInit{

    valCheck: string[] = ['remember'];

    // password : string;

    // email : string;



    login= new FormGroup({
        username: new FormControl(''),
        password: new FormControl('')
      });

    constructor(public layoutService: LayoutService, public loginService: LoginServiceService,
        public fb: FormBuilder) { }

    // constructor(public layoutService: LayoutService) { }
    ngOnInit() {
    }

    OnSignin(){
        console.log(this.login.value);
        this.loginService.login(this.login.value).subscribe(res => {
            var authResponse = JSON.parse(JSON.stringify(res));
            console.log(authResponse);
            if(authResponse.success){

              this.loginService.authenticate(res);
            }else{
            //   this._snackBar.open(authResponse.message,"close", {
            //     duration: 2000,
            //   });
              console.log(authResponse);
            }
          });
    }

    OnSignup(){
        this.loginService.signup(this.login.value).subscribe(res => {
            var authResponse = JSON.parse(JSON.stringify(res));
            console.log(authResponse);
            if(authResponse.success){

            //   this.loginService.authenticate(res);

            }else{
            //   this._snackBar.open(authResponse.message,"close", {
            //     duration: 2000,
            //   });
              console.log(authResponse);
            }
          });
    }
}

import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { ApiService } from 'src/app/demo/service/ApiService';
import { Component } from '@angular/core';

@Component({
    selector: 'formlayout-component',
    templateUrl: './formlayout.component.html'
})
export class FormLayoutComponent {

    selectedState: any;

    posts: any[];

    loginForm= this.fb.group({
        Temu_URL: new FormControl(''),
        product_number: new FormControl(null)
      });

    OpenAI_SettingForm= this.fb.group({
        Title_prompt: new FormControl(''),
        Description_prompt: new FormControl('')
    });

    constructor(private apiService: ApiService, public fb: FormBuilder) {}

    // dropdownItems = [
    //     { name: 'Option 1', code: 'Option 1' },
    //     { name: 'Option 2', code: 'Option 2' },
    //     { name: 'Option 3', code: 'Option 3' }
    // ];

    Search(){
        let data: FormData = new FormData();
        data.append('search_url', this.loginForm.value.Temu_URL);
        data.append('search_number', this.loginForm.value.product_number);
        console.log(this.loginForm.value)

        this.apiService.getPosts(data).subscribe(res => {
            console.log(res.data);
        });
    }

    Update_product(){
        let data: FormData = new FormData();
        data.append('title_prompt', this.OpenAI_SettingForm.value.Title_prompt);
        data.append('description_prompt', this.OpenAI_SettingForm.value.Description_prompt);
        console.log(this.OpenAI_SettingForm.value)

        this.apiService.openai_setting(data).subscribe(res => {
            console.log(res.data);
        });
    }
}

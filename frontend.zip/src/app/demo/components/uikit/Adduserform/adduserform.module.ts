import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AdduserFormComponent } from './adduserform.component';
import { AdduserFormRoutingModule } from './adduserform-routing.module';
import { ApiService } from 'src/app/demo/service/ApiService';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { NgModule } from '@angular/core';

@NgModule({
    imports: [
        CommonModule,
        DropdownModule,
        FormsModule,
        ReactiveFormsModule,
        InputTextModule,
        InputTextareaModule,
        ButtonModule,
        AdduserFormRoutingModule
    ],
    providers: [
        ApiService
    ],
    declarations: [AdduserFormComponent]
})
export class AdduserFormModule { }

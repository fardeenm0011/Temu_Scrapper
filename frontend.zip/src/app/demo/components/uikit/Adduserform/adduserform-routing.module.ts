import { AdduserFormComponent } from './adduserform.component';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [RouterModule.forChild([
        { path: '', component: AdduserFormComponent }
    ])],
    exports: [RouterModule]
})
export class AdduserFormRoutingModule { }

import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { Component } from '@angular/core';
import { LoginServiceService } from 'src/app/demo/service/login-service.service';

@Component({
    selector: 'adduserform-component',
    templateUrl: './adduserform.component.html'
})
export class AdduserFormComponent {

    selectedState: any;

    posts: any[];

    AdduserForm= this.fb.group({
        User_Id: new FormControl(''),
        User_Name: new FormControl(''),
        User_Age: new FormControl(null),
        User_Gender: new FormControl(''),
        User_Address: new FormControl(''),
        User_Role: new FormControl(''),
        User_Email: new FormControl(''),
        User_Password: new FormControl(''),
      });

    constructor(private loginService: LoginServiceService, public fb: FormBuilder) {}

    OnSignup(){
        // let data: FormData = new FormData();
        // data.append('Id', this.loginForm.value.User_Id);
        // data.append('Name', this.loginForm.value.User_Name);
        // data.append('Age', this.loginForm.value.User_Age);
        // data.append('Gender', this.loginForm.value.User_Gender);
        // data.append('Address', this.loginForm.value.User_Address);
        // data.append('Role', this.loginForm.value.User_Role);
        // data.append('Email', this.loginForm.value.User_Email);
        // data.append('Password', this.loginForm.value.User_Password);

        this.loginService.signup(this.AdduserForm.value).subscribe(res => {

        });


    }
}

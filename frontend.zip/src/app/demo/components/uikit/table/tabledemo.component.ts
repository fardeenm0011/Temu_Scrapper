import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Customer, Representative } from 'src/app/demo/api/customer';

import { CustomerService } from 'src/app/demo/service/customer.service';
import { LoginServiceService } from 'src/app/demo/service/login-service.service';
import { Product } from 'src/app/demo/api/product';
import { ProductService } from 'src/app/demo/service/product.service';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { UserData } from '../../users';

interface expandedRows {
    [key: string]: boolean;
}

@Component({
    templateUrl: './tabledemo.component.html',
    providers: [MessageService, ConfirmationService],
    styles: [`
        :host ::ng-deep  .p-frozen-column {
            font-weight: bold;
        }

        :host ::ng-deep .p-datatable-frozen-tbody {
            font-weight: bold;
        }

        :host ::ng-deep .p-progressbar {
            height:.5rem;
        }
    `]
})
export class TableDemoComponent implements OnInit {

    customers :  Customer[] = [];

    Id_Column = [];

    Name_Column = [];

    Age_Column = [];

    Gender_Column = [];

    Address_Column = [];

    Birthday_Column = [];

    Email_Column = [];

    Password_Column = [];

    // customers1: Customer[] = [];

    // customers2: Customer[] = [];

    // customers3: Customer[] = [];

    // selectedCustomers1: Customer[] = [];

    // selectedCustomer: Customer = {};

    // representatives: Representative[] = [];

    // statuses: any[] = [];

    // products: Product[] = [];

    // rowGroupMetadata: any;

    // expandedRows: expandedRows = {};

    // activityValues: number[] = [0, 100];

    // isExpanded: boolean = false;

    // idFrozen: boolean = false;

    // loading: boolean = true;

    // @ViewChild('filter') filter!: ElementRef;

    constructor(private loginService: LoginServiceService, private router: Router) { }

    ngOnInit() {
        this.loginService.getUser().subscribe(res => {
            this.customers = JSON.parse(JSON.stringify(res));

            console.log("This is userData", this.customers);
            this.customers.forEach(customer => {
                this.Id_Column.push(customer['Id']);
                this.Name_Column.push(customer['Name']);
                this.Age_Column.push(customer['Age']);
                this.Gender_Column.push(customer['Gender']);
                this.Address_Column.push(customer['Address']);
                this.Birthday_Column.push(customer['Role']);
                this.Email_Column.push(customer['username']);
                this.Password_Column.push(customer['password']);

            })

        });
    }

    OnAdduser() {
        this.router.navigate(['/dashboard/uikit/adduserform']);
    }


}

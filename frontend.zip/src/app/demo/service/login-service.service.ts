import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';

@Injectable()
export class LoginServiceService {

  _url="http://localhost:8000";
  NAME_TOKEN="username";
  TOKEN_KEY="token";
  private memSubject = new Subject();
  lists = this.memSubject.asObservable();

  constructor(private http:HttpClient,private router: Router) { }

  get name() {
    return localStorage.getItem(this.NAME_TOKEN);
  }

  getToken(){
    return localStorage.getItem(this.TOKEN_KEY);
  }

  isAuthenticated(){
    return !!localStorage.getItem(this.TOKEN_KEY);
  }

  tokenHeader() {
    var header = new HttpHeaders();
    header.append('Authorization','Bearer ' + localStorage.getItem(this.TOKEN_KEY));
    return header
  }

  logout(){
    localStorage.removeItem(this.NAME_TOKEN);
    localStorage.removeItem(this.TOKEN_KEY);
    this.router.navigate(['/login']);
    console.log("Logout Successfull");
  }

  getUser() {
    return this.http.post(this._url + '/users/me',
    {
        text: 'Get User Request'
    },
    {
        headers: {
            'Authorization': 'Bearer ' + this.getToken()
        }
    })
  }

  login(userData){
    console.log("LoginCalled", userData);
    return this.http.post(this._url+"/login",userData);
  }

  signup(userData){
    console.log("LoginCalled");
    return this.http.post(this._url+"/signup",userData);
  }

  authenticate(res) {
    var authResponse = JSON.parse(JSON.stringify(res));
    if (!authResponse.token)
        return authResponse;

    localStorage.setItem(this.TOKEN_KEY, authResponse.token)
    localStorage.setItem(this.NAME_TOKEN, authResponse.username)
    // this.router.navigate(['/dashboard']);
    console.log('-----------------------', authResponse.role)
    if(authResponse.role == 'admin')
        this.router.navigate(['/dashboard']);
    else
        this.router.navigate(['/Employeepagedashboard']);
    return authResponse;
  }


}

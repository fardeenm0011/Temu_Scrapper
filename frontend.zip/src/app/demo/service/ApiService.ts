import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable, map} from "rxjs";

import {Injectable} from '@angular/core';

// import * as Auth0 from 'auth0-web';
// import {  Request, RequestMethod, Headers } from '@angular/http';


// import {
//     Patient,
//     ProbabilityPrediction,
// } from "./types";



@Injectable()
export class ApiService {

    SERVER_URL = 'http://localhost:5000';

    constructor(private http: HttpClient) {
    }

    // public predictPatient(patient: Patient): Observable<ProbabilityPrediction[]> {
    //     return this.http.post(`${SERVER_URL}predict`, patient).pipe(map((res:Response) =>res.json));
    // }

    // headers = new HttpHeaders().append('Content-Type' , 'application/json');
    // options = new RequestOptions({headers: this.headers});
    // httpOptions = {
    //   headers: new HttpHeaders({
    //     'Authorization': `Bearer ${Auth0.getAccessToken()}`
    //   })
    // };

    getPosts(data){
      return this.http.post<any>(this.SERVER_URL + '/login', data);
    }

    openai_setting(data){
        return this.http.post<any>(this.SERVER_URL + '/openai', data);
    }

    // public predictPatient(patient: Patient): Observable<ProbabilityPrediction[]> {
    //     return this.http.post(`${SERVER_URL}predict`, patient).pipe(map((res:Response) =>res.json));
    // }

}

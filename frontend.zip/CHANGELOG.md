# Changelog

## 14.0.0

- Folder structure updated.
- Replace app.config.service by layout.service.
- Updated to PrimeNG 14.
- Updated to Angular 14.
- Strict mode support added.
- Documentation updated.
- Added max-width in large screens for landing.
import time
import shopify
import openai
import math
import os
import sys
import datetime
import requests
import json
from pyactiveresource.connection import ResourceNotFound
import logging
import requests

# Set up file logging with an absolute path
log_filename = "/home/ubuntu/shopifyscripts/product_update_log.log"  # Absolute path to the log file
logging.basicConfig(filename=log_filename, level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')


# Make stdout unbuffered
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 1)

# Set up OpenAI API
openai_api_key = 'sk-hrj3NfXECs8Tz8n32mJhT3BlbkFJReYfuiyB0dr8igxf'
openai_timeout = 60  # Timeout in seconds
openai.api_key = openai_api_key
openai.api_timeout = openai_timeout

# Set up Shopify API
API_VERSION = '2023-04'
SHOP_NAME = 'b5714b-2'
ACCESS_TOKEN = 'shpat_d520e5ce9470605f5a7391cc34b54'
session = shopify.Session(f"{SHOP_NAME}.myshopify.com", API_VERSION, ACCESS_TOKEN)
shopify.ShopifyResource.activate_session(session)

# Read from prompts and tag file
def read_from_file(filename):
    # Use full path
    full_path = f'/home/ubuntu/shopifyscripts/{filename}'
    try:
        current_path = os.getcwd()
        with open(full_path, 'r', encoding='utf-8') as file:
            lines = [line.strip() for line in file.readlines() if line.strip()]
        success_message = f'Successfully read from file {filename}. Content: {lines}'
        print(success_message)
        logging.info(success_message)  # Replacing ws.send with logging
        return lines
    except Exception as e:
        error_message = f'Error reading from file {filename}: {e}'
        print(error_message)
        logging.error(error_message)  # Replacing ws.send with logging
        return []

def get_products_created_in_last_48_hours():
    try:
        all_products = []
        now = datetime.datetime.now()
        foury_eight_hours_ago = now - datetime.timedelta(hours=48)
        
        products = shopify.Product.find(limit=50, created_at_min=foury_eight_hours_ago)
        
        num_products = 0  # Initialize the variable here
        
        while products:
            all_products.extend(products)
            num_products += len(products)  # Increment the count
            
            next_page_info = shopify.ShopifyResource.connection.response.headers.get('Link', '')
            next_page_url = None
            
            for link in next_page_info.split(','):
                if 'rel="next"' in link:
                    next_page_url = link.split(';')[0].replace('<', '').replace('>', '').replace(' ','')
                    break
                    
            if next_page_url:
                try:
                    products = shopify.Product.find(from_=next_page_url)
                except ResourceNotFound:
                    break
            else:
                break
            
            time.sleep(0.5)
            
        success_message = f'Successfully retrieved {num_products} products created in the last 48 hours.'
        print(success_message)
        logging.info(success_message)  # Replacing ws.send with logging
        return all_products
    except Exception as e:
        error_message = f'Error retrieving products: {e}'
        print(error_message)
        logging.error(error_message)  # Replacing ws.send with logging
        return []

    
def update_product(product, title_prompt, description_prompt):
    try:
        # Log that the product is being processed
        processing_message = f'Processing product {product.id}.'
        logging.info(processing_message)

        # Update title
        new_title = update_title(product, title_prompt)
        logging.info(f'Updated title for product {product.id}')

        # Update description
        new_description = update_description(product, description_prompt)
        logging.info(f'Updated description for product {product.id}')

        # Update price and variants
        update_price_and_variants(product)
        logging.info(f'Updated price and variants for product {product.id}')

        # Update product details
        if update_product_details(product, new_title, new_description):
            success_message = f'Successfully updated product {product.id}.'
            print(success_message)
            logging.info(f'Product {product.id} details updated successfully')
        else:
            # Log a message indicating that the update was already successful
            already_updated_message = f'Product {product.id} is already updated.'
            print(already_updated_message)
            logging.info(already_updated_message)

        return True  # Indicate successful processing

    except Exception as e:
        # Handle exceptions for the entire function
        error_message = f'Unexpected error while processing product {product.id}: {e}'
        print(error_message)
        logging.error(error_message)


def update_title(product, title_prompt):
    try:
        retries = 0
        max_retries = 3  # You can adjust the number of retries as needed
        while retries < max_retries:
            response_title = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": f"Alter Produkttitel: {product.title}. {title_prompt}. WICHTIG: gib mir nur den neuen Titel wieder und verzichte auf Erklärungen."}
                ]
            )
            new_title = response_title['choices'][0]['message']['content'].strip()
            return new_title
        raise Exception("Max retries reached for updating title.")
    except openai.error.OpenAIError as e:
        logging.error(f"OpenAI API Error for product {product.id}: {e}")
        new_title = product.title  # Fallback to original title
        return new_title

def update_description(product, description_prompt):
    try:
        html_description_prompt = f"{description_prompt}. WICHTIG: Bitte liefere eine HTML-formatierte Beschreibung mit Überschriften, Absätzen und Listen, wie erforderlich und verzichte auf Erklärungen. Verwende den Produkttitel {product.title}, um die Beschreibung zu erstellen."
        html_description_prompt = html_description_prompt.split('prompt:')[1]
        response_description = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": html_description_prompt }
            ]
        )
        new_description = response_description['choices'][0]['message']['content'].strip()
    except openai.error.OpenAIError as e:
        logging.error(f"OpenAI API Error for product {product.id}: {e}")
        new_description = "<p>No description available.</p>"  # Fallback description
    return new_description

def update_product_details(product, new_title, new_description):
    try:
        product_obj = shopify.Product.find(product.id)
    
        product_obj.title = new_title
        product_obj.body_html = new_description

        if not product_obj.save():
            raise Exception("Failed to save product updates")

        logging.info(f"Product details updated successfully for '{product.title}' (ID: {product.id})")
        return True  # Return True to indicate success
    except Exception as e:
        logging.error(f"Failed to update product {product.id}: {e}")
        return False  # Return False to indicate failure

def round_to_90(price):
    rounded_price = math.ceil(price) - 0.10
    if rounded_price < price:
        rounded_price += 1 - 0.10
    return rounded_price

def update_price_and_variants(product):
    try:
        for variant in product.variants:
            original_price = float(variant.price)

            if original_price <= 2:
                factor = 3
                additional_amount = 2
            elif original_price <= 5:
                factor = 2.5
                additional_amount = 2
            elif original_price <= 10:
                factor = 2.5
                additional_amount = 3
            elif original_price <= 20:
                factor = 2.5
                additional_amount = 3 
            elif original_price <= 30:
                factor = 2
                additional_amount = 5
            elif original_price <= 40:
                factor = 1.8
                additional_amount = 5
            elif original_price <= 50:
                factor = 1.5
                additional_amount = 8
            else:
                factor = 1.5
                additional_amount = 0 

            # Calculate the updated price based on the factor and additional amount
            updated_price = (original_price * factor) + additional_amount
            updated_price = round_to_90(updated_price)

            if updated_price <= 2:
                compared_at_factor = 3
                compared_at_additional_amount = 2
            elif updated_price <= 5:
                compared_at_factor = 2.5
                compared_at_additional_amount = 5
            elif updated_price <= 10:
                compared_at_factor = 2.5
                compared_at_additional_amount = 5
            elif updated_price <= 20:
                compared_at_factor = 2.5
                compared_at_additional_amount = 5
            elif updated_price <= 30:
                compared_at_factor = 2
                compared_at_additional_amount = 8
            elif updated_price <= 40:
                compared_at_factor = 2
                compared_at_additional_amount = 8
            elif updated_price <= 50:
                compared_at_factor = 1.5
                compared_at_additional_amount = 10
            else:
                compared_at_factor = 1.5
                compared_at_additional_amount = 0
            compared_at_price = (updated_price * compared_at_factor) + compared_at_additional_amount
            compared_at_price = round_to_90(compared_at_price)

            variant.price = str(updated_price)
            variant.compare_at_price = str(compared_at_price)
        
            variant.inventory_policy = 'CONTINUE'
            variant.inventory_management = 'shopify'
            variant.weight = 0.5
            variant.weight_unit = 'kg'
            variant.save()
        
        # Log once after all variants are updated
        logging.info(f"All variants for Product ID {product.id} have been updated successfully.")

    except Exception as e:
        logging.error(f"Error updating variants for Product ID {product.id}: {e}")

def activate_product_on_sales_channels(product_id, sales_channel_ids, access_token, shop_name):
    graphql_url = f'https://{shop_name}.myshopify.com/admin/api/2023-10/graphql.json'
    headers = {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': access_token
    }

    for channel_id in sales_channel_ids:
        query = '''
        mutation publishablePublish($id: ID!, $input: [PublicationInput!]!) {
          publishablePublish(id: $id, input: $input) {
            userErrors {
              field
              message
            }
          }
        }
        '''
        variables = {
            'id': f'gid://shopify/Product/{product_id}',
            'input': [{'publicationId': channel_id}]
        }

        try:
            response = requests.post(graphql_url, json={'query': query, 'variables': variables}, headers=headers)
            response_json = response.json()
            if response.status_code == 200 and not response_json.get('errors'):
                logging.info(f'Product {product_id} activated on sales channel {channel_id}')
            else:
                logging.error(f'Failed to activate product {product_id} on sales channel {channel_id}: {response.text}')
                if response_json.get('errors'):
                    logging.error(f'GraphQL Errors: {response_json["errors"]}')
        except Exception as e:
            logging.error(f'Error while activating product {product_id} on sales channel {channel_id}: {e}')

def remove_tag_from_product(product):
    try:
        # Remove 'dailyXimport' from the product's tags
        if 'dailyXimport' in product.tags:
            product.tags = [tag for tag in product.tags.split(', ') if tag != 'dailyXimport']
            product.save()
            logging.info(f"Removed 'dailyXimport' tag from product {product.id}")
            return True
        else:
            logging.info(f"No 'dailyXimport' tag found for product {product.id}")
            return False
    except Exception as e:
        logging.error(f"Error removing tag from product {product.id}: {e}")
        return False

def main():
    try:
        title_prompt, description_prompt = read_from_file('prompts.txt')
        
        # Define the sales channel IDs
        sales_channel_ids = [
            'gid://shopify/Publication/170141319471',  # Online Store
            'gid://shopify/Publication/170141450543',  # Facebook & Instagram
            'gid://shopify/Publication/170141581615',  # Google & YouTube
            'gid://shopify/Publication/181297479983',  # TikTok
            'gid://shopify/Publication/214678962479',  # Inbox
            'gid://shopify/Publication/215496294703'   # Shopify-API
        ]

        while True:
            all_products = get_products_created_in_last_48_hours()
            logging.info(f'Successfully retrieved {len(all_products)} products created in the last 48 hours.')

            filtered_products = [product for product in all_products if 'dailyXimport' in product.tags]
            logging.info(f'Successfully filtered {len(filtered_products)} products.')

            if not filtered_products:
                logging.info("No products with 'dailyXimport' tag found. Exiting the loop.")
                break

            for product in filtered_products:
                process_product(product, title_prompt, description_prompt, sales_channel_ids)

        logging.info('Main function completed successfully.')

    except Exception as e:
        logging.error(f'Error in main function: {e}')

def process_product(product, title_prompt, description_prompt, sales_channel_ids):
    max_retries = 3
    wait_time = 10

    for attempt in range(max_retries):
        try:
            logging.info(f'Attempt {attempt + 1} for processing product {product.id}')
            if update_product(product, title_prompt, description_prompt):
                activate_product_on_sales_channels(product.id, sales_channel_ids, ACCESS_TOKEN, SHOP_NAME)
                if remove_tag_from_product(product):
                    logging.info(f"Successfully updated and processed product {product.id}")
                else:
                    logging.error(f"Failed to remove 'dailyXimport' tag for product {product.id}")
                break
        except Exception as e:
            logging.error(f'Error while processing product {product.id} on attempt {attempt + 1}: {e}')
            time.sleep(wait_time)
            if attempt == max_retries - 1:
                logging.error(f'Failed to process product {product.id} after {max_retries} attempts.')

if __name__ == '__main__':
    main()

const express=require('express');
const cors= require('cors');
const app= express();
var bodyParser= require('body-parser');
const port=8000;
var jwt= require('jsonwebtoken');
var mysql = require('mysql'); 

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "test2",
    multipleStatements:true
});

con.connect(function(err) {
    if (err) {
        console.log(err);
    }else{
        console.log("DB Connected!");
    }
});

app.use(function myCors(req, res, nxt) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,OPTIONS,DELETE');
    res.header('Access-Control-Allow-Credentials','true');
    res.header('Access-Control-Allow-Headers', 'Access-Control-Allow-Origin, Content-Type, Accept, Accept-Language, Authorization, Origin, User-Agent');
    if(req.method === 'OPTIONS') {
        res.sendStatus(204);
    }
    else {
        nxt();
    }
});
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.post('/login',(req,res)=>{
    console.log('Login requested!!')
    console.log(req.body);
    let query=`SELECT * FROM users WHERE Email= BINARY "${req.body.username}" and Password=BINARY "${req.body.password}";`
    let Role=''
    con.query(query, (err,result)=>{
        
        if(result.length > 0){
            Role = result[0].Role;
            var token= jwt.sign(req.body.username,'123');
            res.status(200).json({success:true,username:req.body.username,role:Role,token});
        }else{
            return res.json({success:false, message:"Email or Password is incorrect"});
            console.log(req.body);
        }
    });
});

app.post('/signup',(req,res)=>{
    console.log('SignUp requested!!')
    console.log(req.body);
    let query=`INSERT INTO users (Id,Name,Age,Gender,Address,Role,Email,Password) VALUES ("${req.body.User_Id}", "${req.body.User_Name}","${req.body.User_Age}",
                "${req.body.User_Gender}", "${req.body.User_Address}", "${req.body.User_Role}", "${req.body.User_Email}", "${req.body.User_Password}");`
    con.query(query, (err,result)=>{
        console.log(result,err);
        if(result.length>0 ){
            var token= jwt.sign(req.body.username,'123');
            res.status(200).json({success:true,username:req.body.username,token});
        }else{
            return res.json({success:false,message:"Email or Password is incorrect"});
        }
    });
});
app.post('/users/me',(req,res)=>{
    console.log("Get User Requested");
    let query=`SELECT * FROM users`
    if(req.body.text == 'Get User Request')
        {
            con.query(query,(err,result)=>{
                if(!err){
                    res.send(result);
                }else{
                    console.log(err);
                }
            });
        }
    else
        res.send(null)
});

app.listen(port , ()=>{ console.log(`Server running on...http://localhost:${port}`)});
from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand
from api import create_app
from flask import Flask
# from flask_restful import Api, Resource, reqparse, Resource
from flask_cors import CORS


# sets up the app

# app = Flask(__name__)
# api = Api(app)
# CORS(app, origins=['address of your node app'])
# parser = reqparse.RequestParser()
# parser.add_argument('text')

app = create_app()

CORS(app, origins=['http://localhost:8000'])

manager = Manager(app)

# adds the python manage.py db init, db migrate, db upgrade commands
# manager.add_command("db", MigrateCommand)

@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

@manager.command
def runserver():
    app.run(debug=True, host="localhost", port=3001)


@manager.command
def runworker():
    app.run(debug=False)


# @manager.command
# def recreate_db():
#     """
#     Recreates a database. This should only be used once
#     when there's a new database instance. This shouldn't be
#     used when you migrate your database.
#     """
#     db.drop_all()
#     db.create_all()
#     db.session.commit()


if __name__ == "__main__":
    manager.run()

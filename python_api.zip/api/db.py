from flask_sqlalchemy import SQLAlchemy

# instantiate database object
db = SQLAlchemy()

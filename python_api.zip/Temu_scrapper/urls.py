from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pickle
import os
import undetected_chromedriver as uc
from bs4 import BeautifulSoup
import time
from webdriver_manager.chrome import ChromeDriverManager

# Download and get the path of ChromeDriver executable
chrome_driver_path = ChromeDriverManager().install()
options = uc.ChromeOptions()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
driver = uc.Chrome(executable_path=chrome_driver_path, options=options)

def input_url(productlisturl, type_=str):
    if(type_ not in (str, int, float)): 
        raise ValueError("Expected str, int or float.")  

    test = productlisturl    
    ret = type_(test)
    
    while True:
        test = productlisturl    
        try:
            ret = type_(test)
        except ValueError:
            print("Invalid type, enter again.")                
        else:
            break    

    return ret

def change_region_language(region, language):
    time.sleep(0.1)
    try:
        privacy = driver.find_elements(By.CLASS_NAME, "autoScale-18RRC")
        reject_all = privacy[0]
        driver.execute_script("arguments[0].click();", reject_all)
    except:
        time.sleep(0.3) 
        privacy = driver.find_elements(By.CLASS_NAME, "autoScale-18RRC")
        reject_all = privacy[0] 
        reject_all = driver.find_element(By.CLASS_NAME, "autoScale-18RRC")     
        driver.execute_script("arguments[0].click();", reject_all)
    alters = driver.find_elements(By.CLASS_NAME, 'regionContainer-2HHDI')
    region_alter = alters[0]
    languages = alters[1]
    driver.execute_script("arguments[0].click();", region_alter)
    time.sleep(0.3)
    region_languages = driver.find_elements(By.CLASS_NAME, 'selectorItem-3XH7M')
    resion_Switzerland = region_languages[44]
    driver.execute_script("arguments[0].click();", resion_Switzerland)
    time.sleep(0.3)
    try:
        region_switches = driver.find_elements(By.CLASS_NAME, 'inner-2ElsT')
        region_switch = region_switches[0]
        driver.execute_script("arguments[0].click();", region_switch)
    except:
        time.sleep(0.3)
        region_switches = driver.find_elements(By.CLASS_NAME, 'inner-2ElsT')
        region_switch = region_switches[0]
        driver.execute_script("arguments[0].click();", region_switch)
    try:
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", languages)
    except:
        time.sleep(1)
        alters = driver.find_elements(By.CLASS_NAME, 'regionContainer-2HHDI')
        #time.sleep(1)
        languages = alters[1]
        driver.execute_script("arguments[0].click();", languages)
    time.sleep(0.3)
    region_languages = driver.find_elements(By.CLASS_NAME, 'selectorItem-3XH7M')
    language_select = None
    if language=='German':
        language_select= region_languages[1]
    else:
        language_select= region_languages[0]
    driver.execute_script("arguments[0].click();", language_select)
    time.sleep(0.3)
    
    
    
    
    

# Configuring undetected_chromedriver

def Scrap_url_toText(language):
    # chrome_driver_path = ChromeDriverManager().install()
    # options = uc.ChromeOptions()
    # options.add_argument('--no-sandbox')
    # options.add_argument('--disable-dev-shm-usage')
    # driver = uc.Chrome(executable_path=chrome_driver_path, options=options)

    print("Please input product list url")
    url = "https://www.temu.com/search_result.html?search_key=demen%20taschen&search_method=user&refer_page_el_sn=200010&srch_enter_source=top_search_entrance_10005&refer_page_name=search_result&refer_page_id=10009_1705472765654_gr0p5i7tcy&refer_page_sn=10009&is_back=1&no_cache_id=5w1as&_x_sessn_id=x2dpbicksq"    
    url_setting = "https://www.temu.com/bgp_region_setting.html?refer_page_name=region&refer_page_id=10023_1705472645849_srfbkq6xat&refer_page_sn=10023&_x_sessn_id=x2dpbicksq"
    driver.get(url_setting)
    change_region_language('Switzerland', language)
    driver.get(url)
    # parent = driver.window_handles[0]
    # time.sleep(0.2)
    # try:
    #     child = driver.window_handles[1]
    # except:
    #     time.sleep(0.2)
    #     child = driver.window_handles[1]
    # driver.switch_to.window(child)
    for i in range(2):
        try:
            time.sleep(0.5)
            driver.execute_script("window.scrollTo(0, window.scrollY + 200)")
            time.sleep(0.5)
            see_more = None
            while see_more == None:
                see_more = driver.find_element(By.CLASS_NAME, "_2U9ov4XG")
                time.sleep(0.5)
            driver.execute_script("arguments[0].click();", see_more)
        except:
           driver.get(url)
           for i in range(2):
            try:
                time.sleep(0.5)
                driver.execute_script("window.scrollTo(0, window.scrollY + 200)")
                time.sleep(0.5)
                see_more = None
                while see_more == None:
                    see_more = driver.find_element(By.CLASS_NAME, "_2U9ov4XG")
                    time.sleep(0.5)
                driver.execute_script("arguments[0].click();", see_more)
            except:
                 driver.get(url)
                
    try: 
        time.sleep(0.5)
        links = driver.find_elements(By.CLASS_NAME, "_2IVkRQY-")
        idx = 0
        with open('inputs.txt', 'a') as f:
            for link in links:
                url = link.get_attribute("href")
            
                f.write(url+"\n")
                print(idx, url)
                idx += 1

        driver.close()
    except:
        driver.close()        

# if __name__ == '__main__':
#     Scrap_url_toText()
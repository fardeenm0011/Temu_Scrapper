from bs4 import BeautifulSoup
import json
import re

class TemuExtractor():

    def __init__(self, page_source):
        self.page_source = page_source
        self.soup = BeautifulSoup(self.page_source, 'html.parser')

        self.parsed_json = self.parse_json()
        self.variant_meta_data = self.extract_variant_meta_data()

        self.left_content = self.soup.find(id="leftContent")
        self.right_content = self.soup.find(id="rightContent")

        self.left_content_children = list(self.left_content.children)
        self.right_content_children = list(self.right_content.children)

        self.display_panel = self.left_content_children[0]
        self.base_image_urls = [0]
        self.discount_price = 0
        self.original_price = 0
        self.product_number = 0
        self.variants_origin_prices = [0]
        self.variants_discount_prices =[0]
        self.variants = [0]
        self.variants_attribute_name = ""
        self.variants_attribute_values = [0]
        self.variants_image = [0]

    def parse_json(self):
        # Regular expression to capture JSON data assigned to window.rawData
        json_pattern = r'window\.rawData\s*=\s*(\{.*?\});'

        # Find the JSON data using regular expression
        json_match = re.search(json_pattern, self.page_source, re.DOTALL)

        if json_match:
            raw_json = json_match.group(1)
            # Attempt to parse the JSON data
            return json.loads(raw_json)


        return None


    def extract_variant_meta_data(self):
        """Get Variant meta data"""
        sku = self.parsed_json['store']['sku']

        data_map = []

        for item in sku:
            sale_price_rich = item['salePriceRich']
            sale_price = sale_price_rich[1]['text']

            line_price_rich = item['linePriceRich']
            line_price = line_price_rich[1]['text']

            if 'specShowImageUrl' not in item:
                img = item['thumbUrl']
            else:
                img = item['specShowImageUrl']

            sku_id = item['skuId']

            data_map.append((sku_id, sale_price, line_price, img))

        sorted_data = sorted(data_map, key = lambda x: x[0])

        final_data = {}

        for sku_id, sale_price, line_price, img in sorted_data:
            final_data[img] = (sale_price, line_price)

        return final_data

    def get_prices(self):
        price_span = self.soup.find("div", { "class" : "_3cZnvUvE" }) 
        discount_div = self.soup.findAll("div", { "class" : "_2AmP6_7S" })
        discount_price_span = discount_div[1].findChildren("span")
        price =0 
        discount_price = 0
        if price_span:

            discount_price = price_span['aria-label']
        if discount_price_span:
            
            price = discount_price_span[0].get_text()

        return price, discount_price
    
    # def get__variants_prices(self):
    #     if self.variants_page_source:
    #         count=0
    #         for self.variant_page_source in self.variants_page_source:                
    #             price_span = self.page_source.soup.find("div", { "class" : "_3cZnvUvE" }) 
    #             discount_div = self.page_source.findAll("div", { "class" : "_2AmP6_7S" })
    #             discount_price_span = discount_div[1].findChildren("span")
    #             if price_span:

    #                 self.variants_discount_prices[count] = price_span['aria-label']
    #             if discount_price_span:
                    
    #                 self.variants_origin_prices[count] = discount_price_span[0].get_text()
    #             count += 1
            
        


    def get_description(self, video_urls):

        description_box = self.right_content_children[-2]

        description_data = list(description_box.children)[1]

        full_description = ""

        for video_url in video_urls:
            video_desc = f"""<iframe src="{video_url}" width="640" height="360" frameborder="0" allowfullscreen></iframe>"""

            full_description += video_desc + '\n'

        # Add extra new line after last video
        if len(video_urls) > 0:
            full_description += '\n'
        idx = 0
        for child in description_box.children:

            desc = ' '.join(child.findAll(text=True))
            full_description += desc + '\n'
            idx += 1
        # Replace new lines with <br> tag
        full_description = full_description.replace("\n", "<br>")
        full_description = full_description.replace("\t", "&emsp;")

        return full_description.strip()

    def get_title(self):
        title = self.right_content_children[0].get_text()

        return title
    
    def get_product_link(self):
        product_info = self.soup.find_all('div', attrs={"class":"_3B7ZM4eM"})
        product_link = product_info[2]
        return product_link

    def get_videos(self):
        # Find all script tags with type="application/ld+json"
        script_tags = self.soup.find_all('script', {'type': 'application/ld+json'})

        video_urls = []

        for tag in script_tags:
            try:
                # Parse the script content as JSON
                data = json.loads(tag.string)

                # Check if contentURL exists and is a video
                if 'contentURL' in data:
                    url = data['contentURL']
                    if url.endswith(('.mp4', '.webm', '.ogg')):  # you can expand this list based on what extensions you expect
                        video_urls.append(url)

            except json.JSONDecodeError:
                # Handle JSON parsing errors, if any
                continue

        return video_urls

    def fix_image_url(self, image_url):
        try:
            return image_url.split('?')[0]
        except:
            return image_url

    def get_images(self):
    
        image_list = list(self.display_panel)[0]

        image_elements = image_list.find_all('img')

        image_ls = []

        for image_element in image_elements:
            
            url = image_element.get('src')

            if url is None:
                url = image_element.get('data-src')

            if url is None:
                continue

            url = self.fix_image_url(url)

            image_ls.append(url)

        return image_ls
        

    def get_variant_label_element(self, variant_div):
        """Gets the label element for an individual variant option"""

        # First, try to find the <div> with the role of 'button'
        label_element = variant_div.find('div', {'role': 'button'})
        
        # If not found, try to find the first child <span>
        if label_element is None:
            label_element = variant_div.find('span', recursive=False)  # recursive=False ensures it only searches for direct children

        if label_element is None:
            print('Could not find variant label element.')

        return label_element

    
    def get_variant_label_data(self, variant_div, single=False):
        """Gets the label for an individiual variant option, like 'Style' or 'Color'"""
        label_element = self.get_variant_label_element(variant_div)
        
        variant_label = None

        # For single
        variant_option = None

        # Extract text until the colon
        if label_element:
            text = label_element.get_text()
            text_parts = text.split(":", 1)

            if text_parts:
                variant_label = text_parts[0].strip()

            if single:
                variant_option = text_parts[1].strip()
            
        if single:
            return variant_label, variant_option
        else:
            return variant_label
 
        
    def get_variant_container(self):
        """Gets the block of HTML that contains ALL variant options - like Style, Color, etc."""
        # Find a div that has a style attribute containing 'background-color'
        div_with_bg_color = self.right_content.find('div', style=lambda s: 'background-color' in s if s else False)

        # Find the next sibling that is also a div
        if div_with_bg_color:
            next_sibling_div = div_with_bg_color.find_next_sibling('div')

            # Continue iterating through sibling divs until we find one without the `data-uniqid` attribute
            while next_sibling_div and next_sibling_div.has_attr('data-uniqid'):
                next_sibling_div = next_sibling_div.find_next_sibling('div')

            # Now, either we have the right div or none exists
            if next_sibling_div:
                return next_sibling_div
            
        return None


    def process_single_variant(self, variant_div):
        """When there's only a single variant option"""
        label, variant_option = self.get_variant_label_data(variant_div, single=True)


        return label, [variant_option]
        

    def is_image_variant(self, variant_option_button_div):

        imgs = variant_option_button_div.find_all('img')

        # If there are no img elements, then it's definitely not an image variant
        if len(imgs) < 1:
            return False

        # We need to rule out icons still.
        # If any of the img elements do NOT have aria-hidden='true'
        # then it's an actual img and not an icon
        for img in imgs:
            parent = img.parent

            aria_hidden = parent.get('aria-hidden')

            if aria_hidden == 'true':
                continue
            
            return True
                

        return False
    
    def create_main_variant_dict(self, text, image_url):

        image_url = self.fix_image_url(image_url)

        if image_url in self.variant_meta_data:
            discount_price, original_price = self.variant_meta_data[image_url]
        else:
            discount_price = None
            original_price = None

        if discount_price is None or original_price is None:
            discount_price = self.discount_price
            original_price = self.original_price

        return {'text': text, 'image_url': image_url, 'discount_price': discount_price, 'original_price': original_price}

    def process_multi_variant(self, variant_div):
        """When there's multiple variant options"""
        label = self.get_variant_label_data(variant_div)


        variant_options = []

        variant_type = ''

        for idx, child in enumerate(variant_div.children):
            # First element is the variant label
            if idx == 0:
                continue

            for variant_option_button_div in child.children:

                image = self.is_image_variant(variant_option_button_div)

                # Image button
                if image:
                    variant_type = 'image'

                    text = ''
                    if 'aria-label' in variant_option_button_div:
                        text = variant_option_button_div['aria-label']
                    
                    img = variant_option_button_div.find('img')

                    image_url = img.get('src')

                    variant_options.append(self.create_main_variant_dict(text, image_url))

                else: # Select button
                    variant_type = 'button'
                    text = variant_option_button_div.get_text()
                    variant_options.append(text)

        return label, variant_type, variant_options
    
    def get_variant_len(self, variant_div):

        variant_children = list(variant_div.children)

        if len(variant_children) == 1:
            return 1

        # Find all elements with attribute role='button', and count them
        buttons = variant_div.find_all(role="button", recursive=True)
        count = len(buttons)

        return count

    
    def get_variants(self, image_urls):
        """Gets a list of all variants, where they have one or multiple options"""

        variant_container = self.get_variant_container()

        if variant_container is None:
            print('Could not find variant container on this page.')
            return None
        
        variant_data = {}

        variant_ls = list(variant_container.children)
            
        found_image_variants = False
        button_variant_labels = []


        for idx, variant_div in enumerate(variant_ls):

            variant_type_len = self.get_variant_len(variant_div)

            if variant_type_len == 1: # Variant only has one option and is display only
                label, variant_options = self.process_single_variant(variant_div)
                variant_data[label] = variant_options

            elif variant_type_len > 1: # Variant has multiple options
                label, variant_type, variant_options = self.process_multi_variant(variant_div)
                variant_data[label] = variant_options

                # Store button variants for later, we might need them if there are no image variants
                if variant_type == 'button':
                    button_variant_labels.append(label) 

                # Check if we had any image variants, if so, remove them from base image urls
                for variant_option in variant_options:
                    if isinstance(variant_option, dict):

                        # Remove from base image urls
                        variant_image_url = variant_option['image_url']

                        # Sometimes the image isn't in base images
                        if variant_image_url in image_urls:
                            image_urls.remove(variant_image_url)

                        found_image_variants = True
            else:
                print('Skipping variant at idx:', idx)
                continue

        default_image = image_urls[0]

        # This means we need to check for a select variant that still has associated images
        if found_image_variants is False:
            if len(button_variant_labels) > 0:
                label = button_variant_labels[-1]
                
                button_data = variant_data[label]

                new_variant_options = []

                for idx, button in enumerate(button_data):
                    corresponding_idx = len(image_urls) - len(button_data) + idx

                    # More variants than images
                    # in this case, we need to use a default image
                    if corresponding_idx < 0:
                        image_url = default_image
                    else:
                        image_url = image_urls[corresponding_idx]
                        # Remove from base image urls
                        image_urls.remove(image_url)

                    new_variant_options.append(self.create_main_variant_dict(button, image_url))

                variant_data[label] = new_variant_options

        return image_urls, variant_data
    
    # def get_variants_name(self):
       
    #     variant_divs = self.soup.findAll("div", { "class" : "wfndu2Un" })
    #     for variant_div in variant_divs:
    #         temp_variant = variant_div.get_text()
    #         self.variants.append(temp_variant)

    #     return self.variants[1:]
    
    def get_variants_image(self):
        variant_divs = self.soup.findAll("div", { "class" : "_1yQ_DLGh" })
        for variant_div in variant_divs:
            temp_variant= variant_div.findChild("img")
            temp_variant_image = temp_variant['src']
            self.base_image_urls.append(temp_variant_image)
       

        return self.base_image_urls
    
    def get_product_ID_description(self):
        
        temp_div = self.soup.findAll("div", { "class" : "_1YBVObhm" })
        product_description_divs = temp_div[:-2]
        product_ID_div = temp_div[-1]
        product_description = ""
        for product_description_div in product_description_divs:
            temp_description = product_description_div['aria-label']
            product_description += (temp_description +",")
        product_ID = product_ID_div['aria-label']
           
        return product_description, product_ID
    
    def get_product_sold_amount(self):
        product_sold_amount_div = self.soup.find("div", { "class" : "WSu-sds6" })
        product_sold_amount = product_sold_amount_div.get_text()
        return product_sold_amount
    
    def get_product_rating(self):
        product_rating_div = self.soup.find("div", { "class" : "_7JDNQb0g" })
        product_rating = product_rating_div['aria-label']
        return product_rating
    
    def get_variant_attribute(self):
        product_attribute_divs = self.soup.find("div", { "class" : "_2aXpqYRk" })
        product_attribute_div = product_attribute_divs.findChild('div')
        product_attribute= product_attribute_div['aria-label']
        return product_attribute
    
    def get_variant_attribute_value(self):
        variant_attribute_value = [0]
        variant_attribute_valute_divs = self.soup.findAll("div", { "class" : "wfndu2Un" })
        for variant_attribute_valute_div in variant_attribute_valute_divs:
            variant_attribute_value.append(variant_attribute_valute_div['aria-label'])
    
        return variant_attribute_value


    def process(self, url, language):

        title = self.get_title()
        product_description, product_ID = self.get_product_ID_description()
        product_sold_amount = self.get_product_sold_amount()
        product_rating = self.get_product_rating()
        
        if language=='German':
            product_ID = re.sub('Artikel-ID:','', product_ID)
            product_sold_amount = re.sub('verkauft, von','', product_sold_amount)
            product_rating = re.sub('Punktzahl','', product_rating)
        else:
            product_ID = re.sub('Item ID:','', product_ID)
            product_sold_amount = re.sub('sold, by','', product_sold_amount)
            product_rating = re.sub('score','', product_rating)
        self.original_price, self.discount_price = self.get_prices()
        video_urls = self.get_videos()
        image_urls = self.get_images()
        Product_url = "https://www.temu.com"+url
       
        try :
            self.base_image_urls, self.variants = self.get_variants(image_urls)
        except :
            self.variants = None
        

        data_dict_English = {'Product ID' : product_ID, 'Product title': title, 'Product URL': Product_url, 'Product description': product_description, 
                     'Product sold amount': product_sold_amount, 'Product rating': product_rating, 'Product images': image_urls, 'Product video': video_urls, 
                     'Discount price': self.discount_price, 'Original price': self.original_price, 'Variants original price' : self.variants_origin_prices, 
                     'Variants discount price' : self.variants_discount_prices, 'Variants image': self.variants_image, 'Variants attribute name' : self.variants_attribute_name,
                     'Variants attribute values' : self.variants_attribute_values
        }
        data_dict_German = {'Artikel-ID' : product_ID, 'Produkt Title': title, 'Produkt URL': Product_url, 'Produkt Beschreibung': product_description, 
                     'Produkt verkauft Menge': product_sold_amount, 'Produkt Bewertung': product_rating, 'Produkt Bilder': image_urls, 'Produkt Video': video_urls, 
                     'Reduzierter Preis': self.discount_price, 'Original Preis': self.original_price, 'Varianten Original Preis' : self.variants_origin_prices, 
                     'Varianten reduzierter Preis' : self.variants_discount_prices, 'Varianten Bilder': self.variants_image, 'Varianten attribut name' : self.variants_attribute_name,
                     'Varianten attribut Werte' : self.variants_attribute_values
        }
          
            
        if language == 'German':
            return data_dict_German
        else:
            return data_dict_English
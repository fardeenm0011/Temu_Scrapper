import requests
from selenium import webdriver
import undetected_chromedriver as uc


url = """https://www.temu.com/ch/1pc-high-pressure-shower-head-multi-functional-hand-held-sprinkler-with-5-modes-360adjustable-detachable-hydro-jet-shower-head-with-pause-switch-all-round-filter-9-8-3-5inch-g-601099512294018.html?top_gallery_url=https%3A%2F%2Fimg.kwcdn.com%2Fproduct%2FFancyalgo%2FVirtualModelMatting%2F7a3e7ff6cd7fd0f84ec26a4127f6d74d.jpg&spec_gallery_id=7104597&refer_page_sn=10125&refer_source=0&freesia_scene=114&_oak_freesia_scene=114&_oak_rec_ext_1=NDE4&refer_page_el_sn=201345&_x_sessn_id=tp4xrti04f&refer_page_name=best_sellers&refer_page_id=10125_1693295240033_qpvky8yc6m"""


try:
    data = requests.get(url)
    print('Requests passed')
except:
    print('Requests failed')


# Initialize Selenium WebDriver
driver = webdriver.Chrome() 

try:
    driver.get(url) 
    driver.quit()
    print('Selenium passed')
except:
    print('Selenium failed')


options = uc.ChromeOptions()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
driver = uc.Chrome(options=options)

try:
    driver.get(url)
    driver.quit()
    print('UC passed')
except:
    print('UC failed')
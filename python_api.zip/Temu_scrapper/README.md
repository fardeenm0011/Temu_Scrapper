# Temu Product Shopify Tool

## Introduction

This tool is designed to scrape product information from specific URLs and generate a CSV file that can be uploaded to Shopify.

## Requirements

- Python 3.x

## Installation and Setup

### Installing Python

1. Visit [Python's official website](https://www.python.org/downloads/)
2. Download the installer for your operating system.
3. Run the installer and follow the on-screen instructions.

### Installing Dependencies

1. Open your terminal (Command Prompt, PowerShell, Terminal, etc.).
2. Navigate to the folder where you have extracted the contents of this ZIP file.
3. Run the following command to install the required Python packages:
   ```
   pip install -r requirements.txt
   ```

## Usage

### Editing inputs.txt

1. Open the `inputs.txt` file located in the main folder.
2. Add one URL per line for the products you want to scrape.
3. Save and close the file.

### Running the Tool

1. Open your terminal and navigate to the folder where the `run.py` file is located.
2. Run the following command:
   ```
   python run.py
   ```
3. The tool will scrape the information and generate a CSV file inside the `outputs` folder.

### Uploading to Shopify

1. Log in to your Shopify admin panel.
2. Go to `Products` > `All products`.
3. Click `Import`.
4. Choose the generated CSV file from the `outputs` folder and follow the on-screen instructions to complete the upload.

## Troubleshooting

- Make sure you have an active internet connection.
- Make sure Python and all dependencies are correctly installed.

## Disclaimer

Use this tool responsibly and ensure you have permission to scrape the websites in question.

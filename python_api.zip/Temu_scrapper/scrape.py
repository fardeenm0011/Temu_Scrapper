from scraper import scrape_url
from temu_extractor import TemuExtractor
from csv_processor import ProductToCSVConverter
from fastfs import read_lines, write_lines
from urllib.parse import urlparse
from fastfs import write_json
from urls import Scrap_url_toText
import json
from translate import Translator
import io

from datetime import datetime

def get_start_timestamp():
    # Generate a timestamp string in the format of M-D-hAPM-S
    timestamp = datetime.now().strftime('%m-%d-%I%p-%M-%S')

    return timestamp

def is_valid_temu_url(url):
    try:
        result = urlparse(url)
        # Ensure URL has both a scheme and a netloc
        if not all([result.scheme, result.netloc]):
            return False

        # Split the netloc into subdomains and domain
        parts = result.netloc.split('.')
        # Check if the domain ends with "temu.com"
        return parts[-2:] == ['temu', 'com']

    except:
        return False
    
def write_json_to_Output(file_data, language, full_path):
    
    with io.open(full_path, 'a', encoding='UTF8') as f:
        # if language == 'German':
        #     file_data_encode = json.dumps(file_data, ensure_ascii=False).encode('utf8')
        #     file_data = file_data_encode.decode()
        json.dump(file_data, f, ensure_ascii=False)

        
def write_json_to_Output_Translate(file, file_data,language):
    # file_data = file_data_to
    # index_translate = ['']
    data_translate = ['']
    translator= Translator(to_lang=language) 
    index = ['Product ID', 'Product title', 'Product description', 'Variants attribute name', 'Variants attribute values',
             'Product sold amount', 'Original price' , 'Discount price', 'Variants original price', 'Variants discount price', 'Product rating', 'Product URL', 
            'Product images', 'Product video', 'Variants image']
    index_translate = ['Produkt Auseis', 'Produkt Title', 'Produkt Beschreibung', 'Varianten attribut name', 'Varianten attribut Werte',
             'Produkt verkauft Menge', 'Original Preis', 'Reduzierter Preis', 'Varianten Original Preis', 'Varianten reduzierter Preis', 
             'Produkt Bewertung', 'Produkt URL', 'Produkt Bilder', 'Produkt Video', 'Varianten Bilder']
    file_translate = [file_data['Product ID'], file_data['Product title'], file_data['Product description'], file_data['Variants attribute name'], 
                      file_data['Variants attribute values'], file_data['Product sold amount'], file_data['Original price'], file_data['Discount price'], 
                      file_data['Variants original price'], file_data['Variants discount price'],  
                      file_data['Product rating'], file_data['Product URL'], file_data['Product images'],
                      file_data['Product video'], file_data['Variants image']]
    # index_translate = ['']
    # for temp in index:
    #     index_temp = translator.translate(temp)
    #     index_translate.append(index_temp)
    for temp in file_translate[:5]:
        data_temp = ''
        temp = str(temp)
        if len(temp)>10:
            tokens = temp.split()
            
            
            for token in tokens:
                try:
                    token_temp= translator.translate(token)
                except:
                    token_temp = token
                data_temp += (token_temp+' ')
           
        else:
            temp_string = str(temp)
            data_temp = translator.translate(temp_string)       
        data_translate.append(data_temp)
    sold_amount = file_translate[5]
    sold_amount.replace("sold", "verkauft")
    sold_amount.replace("by", "von")
    data_translate.append(sold_amount)
    for temp in file_translate[6:]:
        data_translate.append(temp)
        # index_temp = translator.translate(index[i])
        # index_translate.append(index_temp)
    file_translate_json = {index_translate[0] : data_translate[1], index_translate[1] : data_translate[2],
                      index_translate[2] : data_translate[3], index_translate[3] : data_translate[4], index_translate[4] : data_translate[5],
                      index_translate[5] : data_translate[6], index_translate[6] : data_translate[7], index_translate[7] : data_translate[8],
                      index_translate[8] : data_translate[9], index_translate[9] : data_translate[10], index_translate[10] : data_translate[11],
                      index_translate[11] : data_translate[12], index_translate[12] : data_translate[13], index_translate[13] : data_translate[14],
                      index_translate[14] : data_translate[15]
                      }
    # data_translate = str(file_data)
    # file_translate =translator.translate(data_translate)
    # file_translate_json = json.loads(file_translate)
    with open(file, 'a') as f:
        
        json.dump(file_translate_json, f)

def process_url(url, start_timestamp, language, full_path):
    print('Starting:', url)

    html, variant_htmls = scrape_url(url,language)
    
    temu_extractor = TemuExtractor(html)
    parsed_data = None
    if language == 'German':
        parsed_data = temu_extractor.process(url, 'German')
    else:
        parsed_data = temu_extractor.process(url, 'English')
    variants_discount_prices = [0]
    variants_original_prices = [0]
    variants_attribute_name = ''
    variants_attribute_values = [0]
    variants_image = [0]
    if variant_htmls:
        variants_attribute_name = temu_extractor.get_variant_attribute()
        variants_attribute_values = temu_extractor.get_variant_attribute_value()
        variants_image = temu_extractor.get_variants_image()
        for variant_html in variant_htmls:                
            temu_extractor_variant = TemuExtractor(variant_html)
            temp_origin, temp_discount = temu_extractor_variant.get_prices()
            variants_discount_prices.append(temp_discount) 
            variants_original_prices.append(temp_origin)
        parsed_data['Variants discount price'] = variants_discount_prices[1:]
        parsed_data['Variants original price'] = variants_original_prices[1:]
        parsed_data['Variants attribute name'] = variants_attribute_name
        parsed_data['Variants attribute values'] = variants_attribute_values[1:]
        parsed_data['Variants image'] = variants_image[1:]

    if parsed_data is None:
        print('Unable to scrape product, skipping for now...')

    write_json('dress_text.json', parsed_data)
    
    write_json_to_Output(parsed_data, language, full_path)

    print('Finished URL.')

def filter_urls():
    urls = read_lines('inputs.txt')

    remaining_urls = []

    for url in urls:
        url = url.strip()

        # Skip over blank space
        if len(url) < 1:
            continue

        if is_valid_temu_url(url) is False:
            print('INVALID URL:', url)
            print('Removing above URL from file.')
            continue
        product_url=url.split(".com")
        remaining_urls.append(product_url[1])

    return remaining_urls

def update_file(remaining_urls):
    write_lines('inputs.txt', remaining_urls)

def scraping():

    start_timestamp = get_start_timestamp()
    print('Loading inputs.txt. Please ensure there is only one URL per line.')
    #language = 'German'
    language = 'English'
    
    file_name = ''
    if language=='English':
        file_name = f"Temu Scrap English Output -{start_timestamp}.json"
    else:
        file_name = f"Temu Scrap German Output -{start_timestamp}.json"
    full_path = f"output_json/{file_name}"
    # with io.open(full_path, 'a+', encoding='UTF8') as f:
    #     json.dump('', f)
    
    
    Scrap_url_toText(language)
    urls = filter_urls()
    while len(urls) > 0:

        url = urls.pop(0)

        process_url(url, start_timestamp, language, full_path)
       
        update_file(urls)

       
    print('Finished all URLs. Please add more URLs to inputs.txt then restart the program.')

# if __name__ == '__main__':
#     scraping()
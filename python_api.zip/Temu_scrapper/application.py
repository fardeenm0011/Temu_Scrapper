from flask import Flask
from flask_cors import CORS
from flask import request, jsonify
# from scrape import scraping

app = Flask(__name__)

CORS(app, origins=['*'])

@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

@app.route("/login", methods=['POST'])
def signin():
    try:
    
        search_url = request.form.get('search_url')
        search_number = request.form.get('search_number')
        # scraping()
        # print(search_url, search_number)
        # print(type(search_url))
        # print(type(search_number))
        # return jsonify({"email": email, "password": password})
        return jsonify({"data":"Scrapping started"})
    except Exception as Ex:
        return {"statues":400, "message": str(Ex)}
    
@app.route("/openai", methods=['POST'])
def openai():
    try:
    
        title_prompt = request.form.get('title_prompt')
        description_prompt = request.form.get('description_prompt')
        # scraping()
        # print(search_url, search_number)
        # print(type(search_url))
        # print(type(search_number))
        # return jsonify({"email": email, "password": password})
        return jsonify({"data":"OpenAI setting transfered"})
    except Exception as Ex:
        return {"status":400, "message": str(Ex)}

if __name__ == "__main__":
    app.run()    
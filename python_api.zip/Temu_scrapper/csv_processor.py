import csv
import os
import itertools

DEFAULT_COLUMNS = [
    'Product title', 'Product description', 'Product images', 'Product video', 'Original_price', 'Discount_price', 
    'Variants', 'Varient picture', 'Temu Produce number' 
]

DEFAULT_VALUES = {
    "Vendor": "My Store",
    "Variant Grams": "0.0",
    "Variant Inventory Qty": "0",
    "Variant Inventory Policy": "deny",
    "Variant Fulfillment Service": "manual",
    "Variant Requires Shipping": "true",
    "Variant Taxable": "false",
    "Gift Card": "false",
    "Variant Weight Unit": "lb",
    "Included / United States": "true",
    "Included / International": "true",
    "Status": "active",
    "Published": "true"
}

class ProductToCSVConverter:
    def __init__(self, product_data):
        self.product_data = product_data
        self.base_images = product_data['Varient picture'].copy()

        self.variant_dict = product_data['Variants']
        self.rows = []

        self.set_first_row = False
    
        self.img_position = 1
    
    def _generate_handle(self, title):
        # Shopify only allows 255 chars max
        return title.replace(" ", "-").replace('/', '-').lower()[:255]
    
    def _determine_main_variant(self):
        for variant_type, variant_values in self.variant_dict.items():

            # Skip single type variants
            if len(variant_values) < 1:
                continue

            if isinstance(variant_values[0], dict) and 'Product images' in variant_values[0]:
                return variant_type
        return None



    def _generate_variant_rows(self):
        main_variant = self._determine_main_variant()

        variant_combinations = list(itertools.product(*self.variant_dict.values()))

        # If no combinations, create a single "combination" with a blank string for each variant
        if len(variant_combinations) == 0:
            single_combination = tuple([value[0] if value else "" for value in self.variant_dict.values()])
            variant_combinations.append(single_combination)

        for idx_combo, combo in enumerate(variant_combinations):
            row = {col: DEFAULT_VALUES.get(col, "") for col in DEFAULT_COLUMNS}
            row["Handle"] = self._generate_handle(self.product_data['Product title'])

            # Title can only be 255 chars max on shopify
            row["Product title"] = self.product_data['Product title'][:255]
            row["Product description"] = self.product_data['Product description']
            
            # for idx, (variant_name, variant_value) in enumerate(zip(self.variant_dict.keys(), combo), start=1):
            #     # Only populate OptionX Name for the first row
            #     if idx_combo == 0:
            #         row[f"Option{idx} Name"] = variant_name
                    
            #     if isinstance(variant_value, dict):
            #         row[f"Option{idx} Value"] = variant_value['text']
            #         if variant_name == main_variant:
            #             row["Image Src"] = variant_value['image_url']
            #             row["Image Position"] = self.img_position
            #             row['Variant Price'] = variant_value['discount_price']
            #             row["Variant Compare At Price"] = variant_value['original_price']
            #             self.img_position += 1

            #             row["Variant Image"] = variant_value.get('image_url', "") if isinstance(variant_value, dict) else ''

            #     else:
            #         row[f"Option{idx} Value"] = variant_value
            # self.rows.append(row)
    
    def _generate_base_image_rows(self):
        """Generate rows for the remaining base images."""
        for image in self.base_images:
            # Initialize the row only with the necessary columns for base images
            row = {
                "Handle": self._generate_handle(self.product_data["Product title"]),
                "Image Src": image,
                "Image Position": self.img_position

            }

            self.img_position += 1

            self.rows.append(row)
    
    def generate_csv(self, start_timestamp):
        """Convert product data to CSV format."""
        self._generate_variant_rows()
        self._generate_base_image_rows()

        # Write to CSV
        file_name = f"products-{start_timestamp}.csv"
        full_path = f"outputs/{file_name}"

        file_exists = os.path.exists(full_path)

        with open(full_path, "a", newline="", encoding="utf-8") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=DEFAULT_COLUMNS)
            
            # We only need to write the header once
            if not file_exists:
                writer.writeheader()

            for row in self.rows:
                writer.writerow(row)

        if not file_exists:
            print('Created NEW CSV:', file_name)
        else:
            print('Appending to existing CSV:', file_name)

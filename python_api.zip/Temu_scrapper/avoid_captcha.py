from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
import pickle
import os
import undetected_chromedriver as uc
from bs4 import BeautifulSoup
import time
from webdriver_manager.chrome import ChromeDriverManager
import urllib.request
import zipfile